/**
 * Este código define clase Main con su método principal y un método 
 * operativa_cuenta
 * 
 * @author Juan José Catalán Lara
 */
package juanjose.cuentas;

/**
 * Clase Principal que contiene los métodos para operar con cuenta. 
 */
public class Main {
/**
 * Método principal que invoca método operativa_cuenta.
 * 
 * En este método se hace referencia a variable "saldoActual" del tipo double y se inicializa una variable "cantidad" del tipo float con valor 0.
 * Se hace referencia a variable cuenta1 de la clase CCuenta.
 * 
 * @param args Argmentos línea de comandos
 */
    public static void main(String[] args) {
        CCuenta cuenta1;
        double saldoActual;
        float cantidad =0f;
        operativa_cuenta(cantidad);
    }
/**
 * Método para realizar varias operaciones en una cuenta.
 * 
 * Creación de objeto "cuenta1" con valores predeterminados.
 * 
 * Obtención de saldo de la cuenta e impresión en patalla.
 * 
 * Operaciones de retirar e ingreso en cuenta, si alguna operación falla se imprime mensaje en patalla.
 * 
 * @param cantidad cantidad a operar en cuenta. 
 * 
 * @throws Exception si retirada o ingreso fallan.
 */
    private static void operativa_cuenta(float cantidad) {
        CCuenta cuenta1;
        double saldoActual;
        cuenta1 = new CCuenta("Antonio López","1000-2365-85-1230456789",2500,0);
        saldoActual = cuenta1.estado();
        System.out.println("El saldo actual es"+ saldoActual );
        try {
            cuenta1.retirar(2300);
        } catch (Exception e) {
            System.out.print("Fallo al retirar");
        }
        try {
            System.out.println("Ingreso en cuenta");
            cuenta1.ingresar(695);
        } catch (Exception e) {
            System.out.print("Fallo al ingresar");
        }
    }
}