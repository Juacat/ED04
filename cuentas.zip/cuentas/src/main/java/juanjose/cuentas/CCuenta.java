/** 
 * @author Juan José Catalán Lara
 */

package juanjose.cuentas;
/**
 * Esta clase representa a cuenta bancaria
 * Incluye métodos de obtención y establecimiento de valores de propiedades de la cuenta y la realización de operaciones básicas
 */
public class CCuenta {
    
    /**
     * Métodos de obtención y modificación(get y set) de las propiedades de la clase. 
     */
    
    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getCuenta() {
        return cuenta;
    }

    public void setCuenta(String cuenta) {
        this.cuenta = cuenta;
    }

    public double getSaldo() {
        return saldo;
    }


    public void setSaldo(double saldo) {
        this.saldo = saldo;
    }

    public double getTipoInterés() {
        return tipoInterés;
    }

    public void setTipoInterés(double tipoInterés) {
        this.tipoInterés = tipoInterés;
    }

    //propiedades de la clase
    private String nombre; //Nombre del tirular cuenta
    private String cuenta; //Número cuenta
    private double saldo; //Saldo actual cuenta
    private double tipoInterés; //Tipo interes cuenta

    /**
     * Constructor por defecto.
     * Crea nueva instancia de CCuenta e inicializa las propiedades con valores proporcionados.
     */
    public CCuenta()
    {
    }
    
    /**
     * Constructor con parámetros. Crea nueva instancia de CCuenta e inicializa las propiedades con valores proporcionados.
     * @param nom nombre titular cuenta
     * @param cue Número cuenta
     * @param sal Saldo actual cuenta
     * @param tipo Tipo interes cuenta
     */
    
    public CCuenta(String nom, String cue, double sal, double tipo)
    {
        nombre =nom;
        cuenta=cue;
        saldo=sal;
    }

    /**
     * Método de devolución de saldo actual de cuenta
     * @return devuelve saldo
     */
    public double estado()
    {
        return getSaldo();
    }

    /**
     * Método de ingreso de dinero en la cuenta.
     * 
     * @param cantidad cantidad a ingresar.
     * @throws Exception si cantidad es negativa lanza excepción.
     */
    public void ingresar(double cantidad) throws Exception
    {
        if (cantidad<0)
            throw new Exception("No se puede ingresar una cantidad negativa");
        setSaldo(getSaldo() + cantidad);
    }

    /**
     * Método para retirar dinero de la cuenta.
     * 
     * @param cantidad catidad a retirar
     * @throws Exception  si cantidad es negativa o saldo no cubre retirada lanza excepción.
     */
    public void retirar(double cantidad) throws Exception
    {
        if (cantidad <= 0)
            throw new Exception ("No se puede retirar una cantidad negativa");
        if (estado()< cantidad)
            throw new Exception ("No se hay suficiente saldo");
        setSaldo(getSaldo() - cantidad);
    }
}
